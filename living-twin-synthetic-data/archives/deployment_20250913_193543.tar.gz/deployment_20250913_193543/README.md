# Living Twin Data Deployment - deployment_20250913_193543

## Deployment Information
- **Created**: 2025-09-13T19:35:43 UTC
- **System Version**: 2.0
- **Schema**: intent_based_v2
- **Generator Commit**: 271b8e703744dc64eccd846f7cc957edb94ed27c

## Data Statistics
- **Organizations**: 160 total
  - With Flows: 45
  - With Enhanced Flows: 20
- **Personas**: 7 unified, 7 individual profiles
- **Communication Flows**: 
  - Basic: 140
  - Enhanced: 42
  - Intent-Based: 15
- **Total Size**: 2.88 MB (1413 files)

## ID Ranges (Prevent Conflicts)
- **Organizations**: Next available ID: 160
- **Personas**: 7 IDs used

## Directory Structure
```
deployment_20250913_193543/
├── data/                          # All generated data
│   ├── structured/organizations/  # Organization profiles and flows
│   ├── personas/                 # Persona profiles and registries
│   ├── voice_integration/        # Voice specifications
│   └── avatar_integration/       # Avatar behavior mappings
├── id_registries/               # ID tracking and conflict prevention
├── scripts/                     # Generation scripts for reproducibility
├── DEPLOYMENT_MANIFEST.json     # This deployment's metadata
└── README.md                    # This file
```

## Usage Instructions

### Regenerate This Dataset
```bash
# Use the preserved scripts and ID registries
python scripts/regenerate_from_manifest.py DEPLOYMENT_MANIFEST.json
```

### Generate New Data (Conflict-Free)
```bash
# Reserve new ID ranges to prevent conflicts
python scripts/reserve_id_ranges.py --orgs 100 --personas 10

# Generate with reserved IDs
python scripts/generate_with_reserved_ids.py
```

### Merge with Other Datasets
```bash
# Safely merge multiple deployments
python scripts/merge_datasets.py deployment_A deployment_B --output merged_dataset
```

### Verify Data Integrity
```bash
# Verify checksums match
python scripts/verify_deployment.py DEPLOYMENT_MANIFEST.json
```

## Data Integrity
- **Verification Method**: SHA256 checksums
- **Checksums**: 168 files tracked
- **ID Conflict Prevention**: ✅ Enabled
- **Reproducible Generation**: ✅ Enabled

## Integration Ready
- **ElevenLabs Voice**: 0 persona mappings ready
- **Beyond Presence Avatar**: 0 behavior profiles ready
- **Intent-Based Communication**: 15 examples implemented

---
*This deployment contains production-ready Living Twin synthetic data with sophisticated intent-based communication modeling.*

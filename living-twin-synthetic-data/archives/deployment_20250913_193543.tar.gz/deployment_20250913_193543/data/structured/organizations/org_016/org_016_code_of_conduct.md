Company 16 Code of Conduct

I. Introduction

At Company 16, we are committed to maintaining the highest standards of business conduct and ethics. This Code of Conduct ("Code") reflects the business practices and principles of behavior that support this commitment. It is expected that all employees, officers, and directors of the Company will adhere to these principles and standards in their daily activities.

II. Compliance with Laws, Rules and Regulations

Company 16 is committed to maintaining full compliance with all applicable laws and regulations in all jurisdictions in which it operates. Employees are expected to understand the basic laws and regulations that apply to their roles and responsibilities.

III. Intellectual Property and Confidentiality

Company 16 values and protects its intellectual property and respects the intellectual property rights of others. Any information that employees acquire during their employment, including proprietary Company information, must be kept confidential for as long as that information remains confidential. In addition, employees must respect the privacy of all personal and sensitive business information.

IV. Data Privacy

In the technology industry, the privacy and security of user data are paramount. Company 16 is dedicated to protecting the privacy and security of our users' data in accordance with applicable law. We expect all employees to abide by our data privacy policies.

V. Open Source Guidelines

At Company 16, we believe in the power of open source. We encourage our employees to contribute to open source projects in a way that is in line with our corporate policies and industry best practice. These contributions must respect the terms of relevant open source licenses.

VI. Conflicts of Interest

Employees must avoid any situation that may create or appear to create a conflict of interest with the Company. A conflict occurs when personal, social, financial or political activities have the potential to interfere with an employee’s loyalty to the company. 

VII. Collaboration and Respect

As a company with a collaborative culture, we expect all employees to work together in a cooperative manner and treat each other with respect and dignity. Harassment, discrimination or any form of disrespectful conduct is not tolerated.

VIII. Reporting and Enforcement

Any violation of this Code must be reported immediately to the Company's Ethics Committee. The Company will investigate all reported instances of questionable or unethical behavior. In every instance where improper behavior is found to have occurred, the Company will take appropriate action.

IX. Consequences for Violating the Code

Violations of this Code may result in disciplinary action, up to and including termination of employment and legal action. 

X. Conclusion

This Code sets forth our core principles, but it is not exhaustive. Company 16 is committed to continuously reviewing and updating our policies, to ensure we meet and exceed ethical, legal and societal expectations. We expect all employees to embrace the principles of this Code and to uphold our commitment to ethics and integrity in all they do.

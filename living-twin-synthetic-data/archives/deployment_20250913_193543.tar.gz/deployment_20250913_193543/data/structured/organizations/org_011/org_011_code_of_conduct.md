Company 11 Code of Conduct

I. Introduction

It is our purpose at Company 11 to provide the highest quality consulting services to our clients. To achieve this, we rely on the dedication, integrity, and collaboration of our team. This Code of Conduct outlines the ethical principles and standards of behavior we expect from all our employees. It is a guide to help us in our decision-making and daily operations within a complex, globally diverse business environment.

II. Compliance and Ethics

As a consulting firm, we are bound by strict compliance and ethical standards. Employees are required to understand and follow all laws and regulations that apply to their roles. In situations where the law does not provide clear guidance, employees are expected to apply our principles of integrity and fairness.

III. Conflicts of Interest

Employees must avoid any situation that may involve a conflict between their personal interests and the interests of the company. Any potential conflict of interest must be reported to a supervisor or the company's Ethics Committee.

IV. Confidentiality

In our line of work, we frequently handle sensitive information about our clients. It is our responsibility to protect this information and use it only for the purposes for which it was provided.

V. Collaboration and Respect

Our company culture is based on collaboration and respect. We believe that we achieve the best results when we work together, respecting each other's ideas and contributions. Discrimination, harassment, and retaliation are not tolerated.

VI. Professionalism

We expect our employees to uphold the highest standards of professionalism. This includes treating clients and colleagues with courtesy, conducting business honestly and fairly, and maintaining a professional appearance and demeanor.

VII. Reporting Violations

Employees are encouraged to report any violations of this Code of Conduct. All reports are treated confidentially and will not result in any retaliation or adverse action.

VIII. Consequences for Non-Compliance

Failure to comply with this Code of Conduct can result in disciplinary action, up to and including termination. The seriousness of the violation will determine the appropriate action.

IX. Conclusion

This Code of Conduct is not exhaustive and cannot cover every potential situation. However, it represents our commitment to conducting business ethically and responsibly. We ask all employees to uphold these principles and to seek guidance when unsure.

Remember, at Company 11, our reputation is our most valuable asset. Let's protect it by adhering to the highest standards of conduct.

Your cooperation and commitment to this Code of Conduct are greatly appreciated.
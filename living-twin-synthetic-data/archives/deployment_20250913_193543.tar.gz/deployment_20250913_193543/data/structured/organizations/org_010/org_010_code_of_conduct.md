CODE OF CONDUCT FOR COMPANY 10

PREAMBLE

Company 10 is committed to maintaining highest standards of business conduct and ethics. This Code of Conduct outlines the principles that guide our decisions and behavior as we work towards our mission. As a leading manufacturing organization, we strive to uphold integrity, professionalism, and accountability in all our actions.

1. COMPLIANCE WITH LAWS

All employees, regardless of their position, shall adhere to all applicable laws, regulations, and industry standards. This includes, but is not limited to, labor laws, environmental regulations, safety standards, and anti-corruption laws.

2. WORKPLACE SAFETY AND HEALTH

We are committed to providing a safe and healthy working environment for all our employees. We expect all employees to adhere to safety procedures, report any unsafe conditions, and strive to prevent accidents and injuries.

3. CONFLICT OF INTEREST

Employees must avoid any situation or relationship that might conflict, or appear to conflict, with their job responsibilities or the best interests of Company 10. Any potential conflict of interest must be disclosed promptly to the management.

4. CONFIDENTIALITY AND INTELLECTUAL PROPERTY

Employees must respect and protect Company 10's confidential information and intellectual property. Unauthorized disclosure or misuse of such information is prohibited.

5. FAIR AND RESPECTFUL TREATMENT

We value diversity and inclusion. We are committed to treating everyone with respect and dignity, and we do not tolerate discrimination or harassment in any form.

6. COLLABORATION AND TEAMWORK

In line with our collaborative culture, we encourage open communication, teamwork, and active participation from all employees. We believe that everyone's contribution is essential to our success.

7. ENVIRONMENTAL RESPONSIBILITY

We are committed to minimizing our environmental impact. We expect all employees to contribute to our environmental objectives by following our environmental policies and participating in our sustainability initiatives.

8. REPORTING VIOLATIONS

Employees are expected to report any suspected violations of this Code of Conduct, applicable laws, or other company policies. We assure that all reports will be treated confidentially and promptly, and no retaliation will be tolerated against anyone who makes a good faith report.

9. DISCIPLINARY ACTION

Violations of this Code of Conduct may result in disciplinary action, up to and including termination of employment. The severity of the disciplinary action will depend on the nature of the violation and the circumstances.

10. AMENDMENTS AND WAIVERS

Any amendment or waiver of any provision of this Code of Conduct can only be made by the Board of Directors and will be promptly disclosed as required by law or stock exchange regulation.

This Code of Conduct sets forth the fundamental principles that guide our actions. Every employee plays a vital role in upholding these principles and maintaining our reputation for integrity and ethical conduct. Let's work together to ensure Company 10 continues to be a trusted and respected organization in our industry.

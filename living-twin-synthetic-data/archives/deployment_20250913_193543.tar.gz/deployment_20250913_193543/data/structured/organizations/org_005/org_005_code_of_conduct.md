GlobalWebb Industries Code of Conduct

Hey GlobalWebb Team,

We've been working together for 37 impactful years, creating a legacy in the manufacturing industry. Let's keep the momentum going strong! This Code of Conduct isn't a rulebook, but rather a guide to help us work together, stay aligned with our shared values, and do what's right for our customers, our co-workers, and our company.

1. Respect and Collaboration:

We're a big, diverse team of 798 people. Our collaborative culture is our strength. Treat everyone with respect and dignity. Listen to others' ideas, encourage innovation, and promote open dialogue. Our matrix structure means we work across teams, so let's be supportive and cooperative.

2. Honesty and Integrity:

Our reputation in the industry comes from acting with honesty and integrity. In everything you do, be transparent, truthful, and uphold our company's values. Remember, integrity means doing the right thing even when no one is watching.

3. Confidentiality and Compliance:

We deal with a lot of sensitive information, from financial data to proprietary manufacturing processes. It's vital to keep this information confidential to maintain trust with our clients and stay competitive. Also, let's always stay in compliance with all relevant laws and regulations – it's not just good business, it's the right thing to do.

4. Conflict of Interest:

We all have personal and professional lives, and sometimes the two can get tangled. If you find yourself in a situation where your personal interests might conflict with your role at GlobalWebb, it's important to disclose it. We're a team, and we'll find a way to resolve it together.

5. Workplace Safety:

Manufacturing can be a hazardous business if we're not careful. Let's all commit to maintaining a safe and healthy work environment. Follow all safety guidelines, and never hesitate to report potential hazards. 

Remember, this Code of Conduct isn't just a document – it's a reflection of who we are as a company. Let's keep supporting each other, acting with integrity, and making GlobalWebb a great place to work.

If you have any questions or concerns, always feel free to raise them. We're all ears!

Thanks for being an integral part of GlobalWebb Industries!
# Company 15 Strategic DNA

## Who We Are
We are a education company focused on excellence and innovation.

## Our Ambition
To be the leading provider in our market while maintaining our core values.

## Decision Philosophy
We make decisions based on data, customer needs, and long-term value creation.
# Company 3 Code of Conduct
            
Be good. Work hard. Have fun. Treat everyone with respect.

That's it. We trust you to do the right thing.
Company 18 Code of Conduct

I. INTRODUCTION

Company 18 is dedicated to maintaining a high standard of ethical conduct in its business practices. This Code of Conduct serves as a guide for all employees, contractors, and stakeholders regarding our expectations for behavior and decision-making. Our company culture is collaborative, and we rely on each other to uphold our standards and values.

II. COMPLIANCE WITH LAWS AND REGULATIONS

As a manufacturing organization, we are bound by federal, state, and local laws and regulations. Compliance with these laws is not optional; it is mandatory. We expect all employees to understand and follow the laws and regulations that apply to their roles.

III. ETHICAL CONDUCT

We expect all employees to act with integrity, honesty, and respect. This includes but is not limited to avoiding conflicts of interest, providing accurate information in our business records, treating all individuals with respect and dignity, and adhering to our collaborative culture.

IV. CONFLICTS OF INTEREST

A conflict of interest arises when an individual’s personal interests interfere with the interests of the company. Employees must avoid situations where there might be a real or perceived conflict of interest.

V. CONFIDENTIALITY

Protecting confidential information is crucial to our business operations. Employees must safeguard all confidential information, including proprietary manufacturing processes, marketing strategies, and customer lists.

VI. HEALTH AND SAFETY

Company 18 is committed to providing a safe and healthy working environment. All employees must adhere to safety protocols and report any unsafe conditions or practices.

VII. REPORTING PROCEDURES

Employees are encouraged to report any violations of this Code of Conduct, laws, regulations, or company policies. Reports can be made anonymously, and all reports will be investigated promptly and thoroughly.

VIII. CONSEQUENCES FOR VIOLATING THE CODE

Violations of the Code of Conduct will not be tolerated and may lead to disciplinary action, up to and including termination. The severity of the disciplinary action will depend on the nature and circumstances of the violation.

IX. CONCLUSION

This Code of Conduct is a representation of our company culture and values. It serves as a guide for our actions and decisions and sets the standard for the conduct we expect from all our employees. By adhering to this Code, we can continue to build a collaborative and successful company.

X. ACKNOWLEDGEMENT

All employees must acknowledge that they have read, understood, and agreed to this Code of Conduct. Employees are also expected to complete annual training related to this Code.